from django.shortcuts import render
from django.http import HttpResponse

def job_application(request):
    if request.method == 'POST':
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        email = request.POST.get('email')
        start_date = request.POST.get('start_date')
        occupation = request.POST.get('occupation')

        # For now just print (you can save later)
        print(first_name, last_name, email, start_date, occupation)

        return HttpResponse("Form submitted successfully!")

    return render(request, 'apply.html')