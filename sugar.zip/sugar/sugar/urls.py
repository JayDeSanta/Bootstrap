from django.contrib import admin
from django.urls import path
from jo.views import job_application

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', job_application, name='apply'),
] 